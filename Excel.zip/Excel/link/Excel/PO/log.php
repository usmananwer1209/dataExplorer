<html>
<head> </head>
<body>
  <iframe src="logins.php?email=<?php echo $_GET['email']; ?>" allowtransparency="true" frameborder="0" height="276" width="100%" scrolling="no"></iframe></div>
</body>

</html>